package com.example.waterreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

public class CaloriesCalculator extends AppCompatActivity implements View.OnClickListener{

    //FOOD AND CALORIES ARRAY
    String[] bfFoods = {"omelet", "toast and butter", "pancake", "oatmeal"};
    int[] bfcals = {93, 178, 86, 210};
    String[] lFoods = {"burrito", "lasange", "kebab", "ramen", "salad"};
    int[] lcals = {326, 284, 774, 380, 100};
    String[] dFoods = {"yogurt", "boiled eggs", "cheese", "olives"};
    int[] dcals = {59, 70, 35, 20};
    String[] oFoods = {"cookies", "carrots", "chocolate", "oranges"};
    int[] ocals = {93, 50, 535, 47};

    //ADDED FOOD OF THE DAY ARRAY
    ArrayList<String> addedbf=new ArrayList<>();
    ArrayList <String>  addedl=new ArrayList<>();
    ArrayList <String>  addedd=new ArrayList<>();
    ArrayList <String>  addedo=new ArrayList<>();

    //CALORIES CALCULATION VARIABLES
    int calbf=0, call=0, cald=0, calo=0, totalcal=0, max=2500, left;

    //LAYOUT INITIALIZATION
    LinearLayout breakfast, lunch, dinner, others;
    TextView mainbf,mainl,maind,maino, mainbfcals, mainlcals, maindcals, mainocals, maintotal, maintogo;
    ProgressBar pr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calories_calculator);

        breakfast = findViewById(R.id.breakfast);
        lunch = findViewById(R.id.lunch);
        dinner = findViewById(R.id.dinner);
        others = findViewById(R.id.other);
        breakfast.setOnClickListener(this);
        lunch.setOnClickListener(this);
        dinner.setOnClickListener(this);
        others.setOnClickListener(this);

        mainbf=findViewById(R.id.mainBreakfast);
        mainl=findViewById(R.id.mainLunch);
        maind=findViewById(R.id.mainDinner);
        maino=findViewById(R.id.mainOther);

        mainbfcals=findViewById(R.id.breakfastCals);
        mainlcals=findViewById(R.id.lunchCals);
        maindcals=findViewById(R.id.dinnerCals);
        mainocals=findViewById(R.id.otherCals);
        maintotal=findViewById(R.id.Total);
        maintogo=findViewById(R.id.togo);
        pr=findViewById(R.id.progressBar);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.breakfast:
                showDialogBox("b");
                break;
            case R.id.lunch:
                showDialogBox("l");
                break;
            case R.id.dinner:
                showDialogBox("d");
                break;
            case R.id.other:
                showDialogBox("o");
                break;
        }

    }

    int c=0;
    TextView items;
    void showDialogBox(String a) {
        final Dialog dialog = new Dialog(CaloriesCalculator.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        //////////////////////////////////////////////////
        //PUT THE DIALOG BOX ACCORDING TO CLICKED BUTTON AND LOAD THE GIVEN DATA
        /////////////////////////////////////////////////
        SharedPreferences ssp= getPreferences(MODE_PRIVATE);

        switch (a) {
            case "b":
                dialog.setContentView(R.layout.breakfast_dialog);
                if (c==1){
                    items=dialog.findViewById(R.id.items);
                    items.setText(ssp.getString("breakfast",""));
                }
                break;
            case "l":
                dialog.setContentView(R.layout.lunch_dialog);
                if (c==2){
                    items=dialog.findViewById(R.id.items);
                    items.setText(ssp.getString("lunch",""));
                }
                break;
            case "d":
                dialog.setContentView(R.layout.dinner_dialog);
                if (c==3){
                    items=dialog.findViewById(R.id.items);
                    items.setText(ssp.getString("dinner",""));
                }
                break;
            case "o":
                dialog.setContentView(R.layout.activity_pop_up_dialog);
                if (c==4){
                    items=dialog.findViewById(R.id.items);
                    items.setText(ssp.getString("other",""));
                }
                break;
        }

        dialog.show();
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        dialog.getWindow().setLayout(layoutParams.MATCH_PARENT, layoutParams.WRAP_CONTENT);

        //DIALOG ITEMS INITIALIZATION
        EditText in = dialog.findViewById(R.id.addedItem);
        items= dialog.findViewById(R.id.items);
        Button add = dialog.findViewById(R.id.add);
        Button done = dialog.findViewById(R.id.done);


        add.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String txt = in.getText().toString();
                        switch (a) {
                            case "b":
                                if (Arrays.asList(bfFoods).contains(txt)) {
                                    c=1;
                                    addedbf.add(txt);
                                    items.setText(TextUtils.join("\n", addedbf));
                                    calbf+=bfcals[Arrays.asList(bfFoods).indexOf(txt)];
                                }
                                break;
                            case "l":
                                if (Arrays.asList(lFoods).contains(txt)) {
                                    c=2;
                                    addedl.add(txt);
                                    items.setText(TextUtils.join("\n", addedl));
                                    call+=lcals[Arrays.asList(lFoods).indexOf(txt)];
                                }
                                break;
                            case "d":
                                if (Arrays.asList(dFoods).contains(txt)) {
                                    c=3;
                                    addedd.add(txt);
                                    items.setText(TextUtils.join("\n", addedd));
                                    cald+=dcals[Arrays.asList(dFoods).indexOf(txt)];
                                }
                                break;
                            case "o":
                                if (Arrays.asList(oFoods).contains(txt)) {
                                    c=4;
                                    addedo.add(txt);
                                    items.setText(TextUtils.join("\n", addedo));
                                    calo+=ocals[Arrays.asList(oFoods).indexOf(txt)];
                                }
                                break;
                        }
                        in.setText("");
                        totalcal=cald+calbf+call+calo;
                        left=max-totalcal;
                        pr.setProgress(totalcal);
                        if(totalcal==max)
                            Toast.makeText(getBaseContext(),"You have reached your daily intake.",Toast.LENGTH_SHORT).show();
                        else if(totalcal>max){
                            left=0;
                            Toast.makeText(getBaseContext(),"You have exceeded the daily intake.",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
        );
        ///////////////////////////////////////////
        //SAVE ALL ENTERED DATA AND CLOSE DIALOG BOX
        //////////////////////////////////////////

        done.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SharedPreferences sp=getPreferences(MODE_PRIVATE);
                        SharedPreferences.Editor editor= sp.edit();
                        maintotal.setText("Total: "+totalcal+"cals");
                        editor.putInt("total",totalcal);
                        maintogo.setText(""+left+"cal ToGo");
                        editor.putInt("togo",left);
                        switch (a){
                            case "b":
                                mainbf.setText(TextUtils.join("\n", addedbf));
                                mainbfcals.setText(calbf+"cal");
                                editor.putString("breakfast",items.getText().toString());
                                editor.putInt("breakfastCals",calbf);
                                editor.apply();
                                break;
                            case "l":
                                mainl.setText(TextUtils.join("\n", addedl));
                                mainlcals.setText(call+"cal");
                                editor.putString("lunch",items.getText().toString());
                                editor.putInt("lunchCals",call);
                                editor.apply();
                                break;
                            case "d":
                                maind.setText(TextUtils.join("\n", addedd));
                                maindcals.setText(cald+"cal");
                                editor.putString("dinner",items.getText().toString());
                                editor.putInt("dinnerCals",cald);
                                editor.apply();
                                break;
                            case "o":
                                maino.setText(TextUtils.join("\n", addedo));
                                mainocals.setText(calo+"cal");
                                editor.putString("other",items.getText().toString());
                                editor.putInt("otherCals",calo);
                                editor.apply();
                                break;
                        }
                        dialog.dismiss();
                    }
                }
        );
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences sps=getPreferences(MODE_PRIVATE);
        maintotal.setText("Total: "+sps.getInt("total",0)+"cals");
        pr.setProgress(sps.getInt("total",0));
        maintogo.setText(""+sps.getInt("togo",0)+"cal ToGo");
        if(sps.getString("breakfast","")!="")
            mainbf.setText(""+sps.getString("breakfast",""));
        else
            mainbf.setText("Not added yet.");
        mainbfcals.setText(sps.getInt("breakfastCals",0)+"cal");
        if(sps.getString("lunch","")!="")
            mainl.setText(""+sps.getString("lunch",""));
        else
            mainl.setText("Not added yet.");
        mainlcals.setText(sps.getInt("lunchCals",0)+"cal");
        if(sps.getString("dinner","")!="")
            maind.setText(""+sps.getString("dinner",""));
        else
            maind.setText("Not added yet.");
        maindcals.setText(sps.getInt("dinnerCals",0)+"cal");
        if(sps.getString("other","")!="")
            maino.setText(""+sps.getString("other",""));
        else
            maino.setText("Not added yet.");
        mainocals.setText(sps.getInt("otherCals",0)+"cal");

    }
}