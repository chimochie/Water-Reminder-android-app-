package com.example.waterreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

//import com.example.recyelerview.R;
//import com.example.recyelerview.R_app;
//import com.example.recyelerview.R_app2;
//import com.example.recyelerview.RecyclerAdapter;
//import com.example.recyelerview.RecyclerAdapter2;

import java.util.ArrayList;
import java.util.List;

public class JuiceRecycle extends AppCompatActivity {

    RecyclerView mList1,mList2;
    List<R_app> appList;
    List<R_app2> appList2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juice_recycle);

        mList1 = findViewById(R.id.list1);
        mList2 = findViewById(R.id.list2);
        appList = new ArrayList<>();
        appList2=new ArrayList<>();

        appList.add(new R_app(R.drawable.yoyo,"Orange"));
        appList.add(new R_app(R.drawable.lolo,"Strawberry"));
        appList.add(new R_app(R.drawable.roro,"Mango"));
        appList.add(new R_app(R.drawable.coco,"Avocado"));
        appList.add(new R_app(R.drawable.soso,"Lemon"));

        appList2.add(new R_app2(R.drawable.orang));
        appList2.add(new R_app2(R.drawable.strwa));
        appList2.add(new R_app2(R.drawable.mango));

//        public void onClick(View v) {
//
//            final Intent intent;
//            switch (getAdapterPostion()){
//                case 0:
//                    intent =  new Intent(context, FirstActivity.class);
//                    break;
//
//                case 1:
//                    intent =  new Intent(context, SecondActivity.class);
//                    break;
//           ...
//                default:
//                    intent =  new Intent(getApplicationContext(), DefaultActivity.class);
//                    break;
//            }
//            context.startActivity(intent);
//        }

        LinearLayoutManager manager1 = new LinearLayoutManager(this);
        manager1.setOrientation(LinearLayoutManager.HORIZONTAL);
        mList1.setLayoutManager(manager1);

        LinearLayoutManager manager2 = new LinearLayoutManager(this);
        manager2.setOrientation(LinearLayoutManager.HORIZONTAL);
        mList2.setLayoutManager(manager2);

        RecyclerAdapter adaptor1 = new RecyclerAdapter(this,appList);
        mList1.setAdapter(adaptor1);

        RecyclerAdapter2 adaptor2 = new RecyclerAdapter2(this,appList2);
        mList2.setAdapter(adaptor2);


    }

}