package com.example.waterreminder;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.Calendar;

public class WaterReminder extends AppCompatActivity {

    private static final String TAG = "Main Activity";
    // Animation for cups
    AnimationDrawable drink_waterAnimation;

    //update text view per seconds
    float remaining = 4;
    float Goalpercent = 0;
    int Consumed = 0 ;
    int Cuptarget =0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_water_reminder);
        getSupportActionBar().hide();

        ImageView imageView = (ImageView) findViewById(R.id.img);
        imageView.setBackgroundResource(R.drawable.animation);

        drink_waterAnimation = (AnimationDrawable) imageView.getBackground();

        //For updating text view
        TextView textView = findViewById(R.id.remaining);
        TextView goalpercent =findViewById(R.id.percent);
        TextView consum = findViewById(R.id.consumed);
        TextView cuptarget = findViewById(R.id.target);

        //For service
        ImageButton addcup = findViewById(R.id.addcup);
        ImageButton cancel = findViewById(R.id.cancel);

        addcup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                schedulejob(addcup);
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                canceljob(cancel);
            }
        });
        ImageButton caloriepage=findViewById(R.id.caloriesCalculation);
        caloriepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),CaloriesCalculator.class);
                startActivity(i);
            }
        });
        ImageButton profile=findViewById(R.id.viewProfile);
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(WaterReminder.this,MainSetting.class);
                startActivity(i);
            }
        });
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!isInterrupted()) {
                    try {
                        Thread.sleep(6000); // 60000 millis = 1 minute
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                remaining -= 1;
                                Goalpercent +=25;
                                Consumed +=25;
                                Cuptarget +=4;
                                textView.setText(String.valueOf(remaining) + " LT");
                                goalpercent.setText(String.valueOf(Goalpercent) + " %");
                                consum.setText(String.valueOf(Consumed) + " %");
                                cuptarget.setText(String.valueOf(Cuptarget) + " Cups");
                                schedulejob(addcup);
                                while (remaining<0 & Goalpercent>100 & Consumed>100 & Cuptarget>16)
                                { textView.setText(String.valueOf(0)+ " LT");
                                  goalpercent.setText(String.valueOf(100) +" %");
                                  consum.setText(String.valueOf(100) + " %");
                                  imageView.setBackgroundResource(R.drawable.ic_drink_water_5);

                                  }
                            } });
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } } } };
            thread.start();

    }


    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        drink_waterAnimation.start();
    }
    
    public  void schedulejob(View v){
        ComponentName componentName =new ComponentName(this,service.class);
        JobInfo jobInfo = new JobInfo.Builder(123,componentName).build();
        JobScheduler jobScheduler =(JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
        int resultcode = jobScheduler.schedule(jobInfo);
        if(resultcode == JobScheduler.RESULT_SUCCESS){
            Log.d(TAG,"Job Scheduled");
            //Toast.makeText(this, "Drink Water", Toast.LENGTH_SHORT).show();
        }else { Log.d(TAG,"Job Scheduling Failed"); }
    }
    public void canceljob(View v){
        JobScheduler jobScheduler =(JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
        jobScheduler.cancel(123);
        Log.d(TAG,"Job Cancelled");
        //Toast.makeText(this, "Stopped Drink Water", Toast.LENGTH_SHORT).show();
    }
}