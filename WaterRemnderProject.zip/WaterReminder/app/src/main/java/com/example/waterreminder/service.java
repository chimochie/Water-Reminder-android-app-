package com.example.waterreminder;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Handler;
import java.util.logging.LogRecord;


public class service extends JobService {

    private static final String TAG = "JOBSERVICE";
    private boolean jobcancel=false;

    //anthor service
    private Context context;
    private boolean isJobcancelled = false;
    private Intent intent;

    @Override
    public void onCreate() {
        super.onCreate();
        this.context=this;
        intent=new Intent("job"); //implicit intent
    }

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        Log.d(TAG,"Job Starteds");
//        doBackgroundwork(jobParameters);
        return false; }

        //another service
       // Toast.makeText(context, "Job Started", Toast.LENGTH_SHORT).show();
       // ExecutorService executorService= Executors.newSingleThreadExecutor();
       // Handler handler = new Handler(Looper.getMainLooper()) {
        //    @Override
        //    public void publish(LogRecord logRecord) {

        //    }

         //   @Override
         //   public void flush() {



         //   @Override
        //    public void close() throws SecurityException {

        //    }
      //  };
      //  executorService.execute(new Runnable() {
       //     @Override
       //     public void run() {
        //        for (int i =1;i<101;i++){
        //            if (isJobcancelled)
         //               break;
         //       }
          //      int data=i;
          //      handler.post(new Runnable() {

           //     }
          //  }
       /// })
    //}

//    private void doBackgroundwork(final JobParameters jobParameters) {
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
////                for (int i =1;i<10;i++){
////                    Log.d(TAG,"run: " +i);
////                    if (jobcancel){return;}
////                    try {
////                        Thread.sleep(6000);
////                    } catch (InterruptedException e) {
////                        e.printStackTrace();
////                    }
////                }
//                Log.d(TAG,"Job Finished");
//                jobFinished(jobParameters,false);
//            }
//        }).start();
//    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        Log.d(TAG,"Job cancelled before completion");
        jobcancel =true;
        return true;
    }
}
