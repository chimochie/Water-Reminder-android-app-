package com.example.waterreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.airbnb.lottie.LottieAnimationView;

import java.time.Instant;

public class Splash extends AppCompatActivity {

    LottieAnimationView lottieAnimationView1;
    LottieAnimationView lottieAnimationView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        lottieAnimationView1 =findViewById(R.id.waterandalarm);
        lottieAnimationView2 =findViewById(R.id.welcome);

        int time = 5000 ;

        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!isInterrupted()) {
                    try {
                        Thread.sleep(time); // 60000 millis = 1 minute
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                lottieAnimationView1.setAnimation(R.raw.mwater);
                                lottieAnimationView2.setAnimation(R.raw.mwelcome);
                                while (time > 5000)
                                {
                                    Intent intent = new Intent(Splash.this,MainActivity.class);
                                    startActivity(intent);
                                }
                            } });
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } } } };
        thread.start();

    }
}
