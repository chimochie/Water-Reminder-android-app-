package com.example.waterreminder;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class account extends AppCompatActivity {
    ImageView barrow;
    EditText nname, eemail, passsword;
    Button editBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_account);
        Intent i = getIntent();
        MainActivity sign=new MainActivity();
        ArrayList<String> showData= sign.getArray();
        //ArrayAdapter<String> adapter=new ArrayAdapter<String>();
        nname= findViewById(R.id.name);
        eemail=findViewById(R.id.mail);
        passsword=findViewById(R.id.passs);
        editBtn=findViewById(R.id.edit_btn);
        nname.setText(showData.get(0));
        eemail.setText(showData.get(1));
        passsword.setText(showData.get(2));
        barrow = (ImageView) findViewById(R.id.barrow);
        barrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(account.this, MainSetting.class);
                startActivity(i);
            }
        });
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showData.set(0,nname.getText().toString());
                showData.set(1,eemail.getText().toString());
                showData.set(2,passsword.getText().toString());
                Toast.makeText(getBaseContext(), "Profile updated", Toast.LENGTH_SHORT).show();

                //Intent Info
            }
        });

    }
    protected void onPause() {
        super.onPause();
        SharedPreferences shp= getSharedPreferences("SaveData",MODE_PRIVATE);
        SharedPreferences.Editor editor= shp.edit();
        //editor.putInt("weight",Integer.parseInt(weight.getText().toString()));
        editor.putString("name",nname.getText().toString());
        editor.putString("email",eemail.getText().toString());
        editor.putString("password",passsword.getText().toString());
        editor.commit();
    }
    protected void onResume() {
        super.onResume();
        SharedPreferences shp=getSharedPreferences("SaveData",MODE_PRIVATE);
        nname.setText(shp.getString("name",""));
        eemail.setText(shp.getString("email",""));
        passsword.setText(shp.getString("password",""));

    }

}