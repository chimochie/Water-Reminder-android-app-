package com.example.waterreminder;

public class Constants {

    private final static String ROOT_URL ="http://192.168.1.112/final/v1";

    public static final String URL_REGISTER =ROOT_URL+"/registerUser.php";
    public static final String URL_LOGIN = ROOT_URL+"/userLogin.php";
    //public static final String URL_INFO =ROOT_URL+"/addInfo.php";

}
