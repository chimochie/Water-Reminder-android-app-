package com.example.waterreminder;

public class R_app2 {
    int image;


    public R_app2(int image) {
        this.image = image;


    }

    public int getImage() {
        return image;
    }


}
