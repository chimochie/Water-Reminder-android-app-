package com.example.waterreminder;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Info extends AppCompatActivity {
    EditText weight ,height,goal;
    Button submitbtn;
    RadioGroup gender, drink;
    RadioButton male ,female, ml, lt,us,uk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //REMOVE BAR
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_info);
        Intent intent = getIntent();
        /////////////////////////////////
        weight=findViewById(R.id.weight);
        height=findViewById(R.id.height);
        gender=findViewById(R.id.gendergroup);
        male=findViewById(R.id.radioMale);
        female=findViewById(R.id.radiofemale);
        drink=findViewById(R.id.drinkUnit);
        ml=findViewById(R.id.radio6_pirates);
        lt=findViewById(R.id.radio5_pirates);
        uk=findViewById(R.id.radio4_pirates);
        us=findViewById(R.id.radio3_pirates);
        goal=findViewById(R.id.goal);
        ///////////////////////////////
        submitbtn=findViewById(R.id.submitBtn);
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences shp= getSharedPreferences("SaveData",MODE_PRIVATE);
                SharedPreferences.Editor editor= shp.edit();
                editor.putInt("weight",Integer.parseInt(weight.getText().toString()));
                editor.putInt("height",Integer.parseInt(height.getText().toString()));
                editor.putString("goal",goal.getText().toString());
                editor.putBoolean("male",male.isChecked());
                editor.putBoolean("female",female.isChecked());
                editor.putBoolean("ml", ml.isChecked());
                editor.putBoolean("lt", lt.isChecked());
                editor.putBoolean("uk", uk.isChecked());
                editor.putBoolean("us", us.isChecked());
                Intent in=new Intent(getApplicationContext(),WaterReminder.class);
                startActivity(in);
                editor.commit();
                SaveData();
            }
        });

    }
    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences shp= getSharedPreferences("SaveData",MODE_PRIVATE);
        SharedPreferences.Editor editor= shp.edit();
        editor.putInt("weight",Integer.parseInt(weight.getText().toString()));
        editor.putInt("height",Integer.parseInt(height.getText().toString()));
        editor.putString("goal",goal.getText().toString());
        editor.putBoolean("male",male.isChecked());
        editor.putBoolean("female",female.isChecked());
        editor.putBoolean("ml", ml.isChecked());
        editor.putBoolean("lt", lt.isChecked());
        editor.putBoolean("uk", uk.isChecked());
        editor.putBoolean("us", us.isChecked());
        editor.commit();

    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences shp=getSharedPreferences("SaveData",MODE_PRIVATE);
        int w=shp.getInt("weight",0);
        int h=shp.getInt("height",0);
        String g=shp.getString("goal","");
        //boolean m=shp.getBoolean("male",false);
        male.setChecked(shp.getBoolean("male",false));
        female.setChecked(shp.getBoolean("female",false));
        weight.setText(String.valueOf(w));
        height.setText(String.valueOf(h));
        ml.setChecked(shp.getBoolean("ml",false));
        lt.setChecked(shp.getBoolean("lt",false));
        us.setChecked(shp.getBoolean("us",false));
        uk.setChecked(shp.getBoolean("uk",false));

        goal.setText(g);
    }

    private void SaveData() {
        RadioButton rd,dr;
        int checkedbtn=gender.getCheckedRadioButtonId();
        rd=findViewById(checkedbtn);
        int checkedDrink = drink.getCheckedRadioButtonId();
        dr=findViewById(checkedDrink);
        final String genderr = rd.getText().toString().trim();
        final String weightt = weight.getText().toString().trim();
        final String heightt = height.getText().toString().trim();
        final String drinkingUnit = dr.getText().toString().trim();
        final String goall = goal.getText().toString().trim();


//        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_INFO,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//
//
//                        try {
//                            JSONObject jsonObject = new JSONObject(response);
//
//                            Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();
//
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                params.put("gender", genderr);
//                params.put("weight", weightt);
//                params.put("height", heightt);
//                params.put("drinkingUnit", drinkingUnit);
//                params.put("goal", goall);
//                return params;
//            }
//        };
//        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);

    }
}
