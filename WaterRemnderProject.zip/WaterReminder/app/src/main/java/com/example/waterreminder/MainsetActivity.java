package com.example.waterreminder;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Switch;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
//implements View.OnClickListener
public class MainsetActivity extends AppCompatActivity  {
    CardView alarm,acc,set,out;
    ImageView backarrow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        Intent i=getIntent();

        set=(CardView) findViewById(R.id.setting);
        acc=(CardView) findViewById(R.id.acc);
        out=(CardView) findViewById(R.id.out);
        alarm = findViewById(R.id.alarm);
        backarrow=(ImageView)findViewById(R.id.backarrow);
//        barrow=(ImageView)findViewById(R.id.barrow);
        set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainsetActivity.this, set.class);
                startActivity(i);
            }
        });
        acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainsetActivity.this, account.class);
                startActivity(i);
            }
        });
        backarrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainsetActivity.this,WaterReminder.class);
                startActivity(i);
            }
        });
        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainsetActivity.this, login.class);
                startActivity(i);
            }
        });
        alarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(MainsetActivity.this, alarm.class);
                startActivity(i);
            }
        });
        }}