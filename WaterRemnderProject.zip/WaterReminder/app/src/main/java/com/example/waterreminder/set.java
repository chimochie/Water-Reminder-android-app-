package com.example.waterreminder;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

public class set extends AppCompatActivity {
    Switch s;
    Boolean isDarkMode=false;
    ImageView barrow;
    TextView about;
    TextView lan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLocale();
        getSupportActionBar().hide();
        setContentView(R.layout.activity_set);

        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle(getResources().getString(R.string.app_name));


        about=findViewById(R.id.about);
        s=findViewById(R.id.s1d);
        Intent intent=getIntent();
        Intent i=getIntent();
        lan=findViewById(R.id.lan);
        lan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showChangeLanguageDialog();
            }
        });
        barrow=(ImageView)findViewById(R.id.barrow);
        barrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(set.this,MainsetActivity.class);
                startActivity(i);
            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(set.this,about.class);
                startActivity(i);
            }
        });

        isDarkMode=getDarkModeStatus();
        if(isDarkMode){
            s.setText("Light Mode");
        }
        else {
            s.setText("Dark Mode");
        }
        s.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isDarkMode){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    s.setText("Dark Mode");
                    isDarkMode=false;
                }
                else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    s.setText("Light Mode");
                    isDarkMode=true;
                }
            }
        });
    }

    private Boolean getDarkModeStatus() {
        int nightModeFlags = set.this.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        switch (nightModeFlags){
            case Configuration.UI_MODE_NIGHT_YES:
                return true;
            case Configuration.UI_MODE_NIGHT_NO:
                return false;
            case Configuration.UI_MODE_NIGHT_UNDEFINED:
                return false;
        }
        return false;
    }

    private void showChangeLanguageDialog() {
        final String[] listItems={"French","Korean","Turkish","English","Arabic"};
        AlertDialog.Builder builder=new AlertDialog.Builder(set.this);
        builder.setTitle("Choose Your Language....");
        builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(i==4){
                    setLocale("ar");
                    recreate();
                }
                else if(i==0){
                    setLocale("fr");
                    recreate();
                }else if(i==1){
                    setLocale("ko");
                    recreate();
                }
                else if(i==2){
                    setLocale("tr");
                    recreate();
                }
                else if(i==3){
                    setLocale("");
                    recreate();
                }
                dialogInterface.dismiss();

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
    }

    private void setLocale(String lang) {
        Locale locale=new Locale(lang);
        Locale.setDefault(locale);
        Configuration configuration=new Configuration();
        configuration.locale=locale;
        getBaseContext().getResources().updateConfiguration(configuration,getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences.Editor editor=getSharedPreferences(".settings",MODE_PRIVATE).edit();
        editor.putString("My_Lang",lang);
        editor.apply();
    }
    public void loadLocale(){
         SharedPreferences s=getSharedPreferences(".settings", Activity.MODE_PRIVATE);
         String lan=s.getString("My_Lang","");
         setLocale(lan);
    }

}
