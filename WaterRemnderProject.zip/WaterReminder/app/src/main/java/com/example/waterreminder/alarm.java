package com.example.waterreminder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewDebug;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class alarm extends AppCompatActivity implements View.OnClickListener {
    private int notificationId = 1;
ImageView barrow;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        getSupportActionBar().hide();
        barrow=(ImageView)findViewById(R.id.barrow);
        barrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(alarm.this,MainsetActivity.class);
                startActivity(i);
            }
        });

        findViewById(R.id.b1set).setOnClickListener(this);
        findViewById(R.id.b2del).setOnClickListener(this);
        Intent i=getIntent();
    }

    @Override
    public void onClick(View view) {
        EditText txt=findViewById(R.id.txt);
        TimePicker timePicker=findViewById(R.id.pick);

        Intent intent=new Intent(alarm.this,AlarmReceiver.class);
        intent.putExtra("notificationId",notificationId);
        intent.putExtra("todo",txt.getText().toString());

        PendingIntent alarmIntent=PendingIntent.getBroadcast(alarm.this,0,intent,PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager alarm=(AlarmManager) getSystemService(ALARM_SERVICE);




        switch (view.getId()) {
            case R.id.b1set:
                int hour = timePicker.getCurrentHour();
                int minute = timePicker.getCurrentMinute();
                Calendar startTime = Calendar.getInstance();
                startTime.set(Calendar.HOUR_OF_DAY, hour);
                startTime.set(Calendar.MINUTE, minute);
                startTime.set(Calendar.SECOND, 0);
                long alarmStartTime = startTime.getTimeInMillis();

                // Set Alarm
//                alarm.set(AlarmManager.RTC_WAKEUP, alarmStartTime, alarmIntent);
//
                alarm.setRepeating(AlarmManager.RTC_WAKEUP, startTime.getTimeInMillis(),
                        1000*60 , alarmIntent);

                Toast.makeText(this, "Alarm ON", Toast.LENGTH_SHORT).show();
                break;

            case R.id.b2del:
                alarm.cancel(alarmIntent);
                Toast.makeText(this, "Alarm OFF", Toast.LENGTH_SHORT).show();
                break;
        }



    }
}